# Basit Hesap Makinesi

Bu proje, Python kullanarak oluşturulmuş basit bir hesap makinesidir. Toplama, çıkarma, çarpma ve bölme işlemleri yapabilmektedir.

## Nasıl Çalıştırılır

1. Python yüklü olduğundan emin olun.
2. `hesap_makinesi.py` dosyasını çalıştırın:
   ```sh
   python hesap_makinesi.py

## Özellikler
- **Toplama**: İki sayıyı toplar.
- **Çıkarma**: İlk sayıdan ikinci sayıyı çıkarır.
- **Çarpma**: İki sayıyı çarpar.
- **Bölme**: İlk sayıyı ikinci sayıya böler.

## Özellikler_2

- Toplama, çıkarma, çarpma ve bölme işlemleri
- Kullanıcı dostu komut satırı arayüzü
- Sıfıra bölme gibi hatalar için uyarı mesajları
- Yanlış işlem seçildiğinde hata mesajları

## Bilinen Sorunlar

- Çok büyük sayılarla işlem yapıldığında hatalar olabilir.
- Yalnızca temel aritmetik işlemler desteklenmektedir.